# By Domain

What field the work belongs to. 8 values across 83 projects.

| Domain | Projects | Folder |
|---|:-:|---|
| [Civil & CAD Engineering](Civil-CAD-Engineering/) | 1 | [`Civil-CAD-Engineering/`](Civil-CAD-Engineering/) |
| [Cyber Security (Defensive)](Cyber-Security-Defensive/) | 20 | [`Cyber-Security-Defensive/`](Cyber-Security-Defensive/) |
| [Data Analytics & Science](Data-Analytics-Science/) | 15 | [`Data-Analytics-Science/`](Data-Analytics-Science/) |
| [Design, Marketing & Content](Design-Marketing-Content/) | 4 | [`Design-Marketing-Content/`](Design-Marketing-Content/) |
| [Electric Vehicles & Embedded Engineering](Electric-Vehicles-Embedded-Engineering/) | 11 | [`Electric-Vehicles-Embedded-Engineering/`](Electric-Vehicles-Embedded-Engineering/) |
| [Finance, Energy & Excel Modelling](Finance-Energy-Excel-Modelling/) | 13 | [`Finance-Energy-Excel-Modelling/`](Finance-Energy-Excel-Modelling/) |
| [Product Management & Strategy](Product-Management-Strategy/) | 12 | [`Product-Management-Strategy/`](Product-Management-Strategy/) |
| [Software, Cloud & Web](Software-Cloud-Web/) | 7 | [`Software-Cloud-Web/`](Software-Cloud-Web/) |

[← Lens dashboard](../README.md)