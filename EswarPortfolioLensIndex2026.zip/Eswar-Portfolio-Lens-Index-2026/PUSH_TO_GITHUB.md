# Push
1. Replace `YOUR-USERNAME` with your GitHub username everywhere: `grep -rl "YOUR-USERNAME" . | xargs sed -i 's/YOUR-USERNAME/<your-username>/g'`
2. Create repo **Eswar-Portfolio-Lens-Index-2026** on GitHub (description in `REPO_NAME_AND_DESCRIPTION.txt`), then:
```bash
git init && git add . && git commit -m "Portfolio lens index: 83 projects x 10 lenses" && git branch -M main
git remote add origin https://github.com/<your-username>/Eswar-Portfolio-Lens-Index-2026.git && git push -u origin main
```
3. Settings → Pages → main / root → the dashboard is live at `https://YOUR-USERNAME.github.io/Eswar-Portfolio-Lens-Index-2026/`.
4. This repo links into `Eswar-Master-Project-Portfolio-2026`; push that one first so every link resolves.
