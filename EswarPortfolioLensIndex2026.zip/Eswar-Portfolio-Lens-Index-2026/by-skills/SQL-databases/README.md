# Skills: SQL & databases

3 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Portfolio Submission Package** | HEXA Solutions | Master documents that wrap the 13 projects: Capability Statement, 62-page Project Book, Methods Book, Operator–Analyst research paper and monograph, 100% Fitment Dossier, Evidence Casebook, Tools Mastery, 110-page Master Book, 7-tab Showcase Dashboard, Level-3 Learning Reflection deck, Interview Master Knowledge Book. | Only dual-route verified figures printed: 99 AED/sqft, CSAT 4.48→3.66, r = −0.60 | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/00-Portfolio-Package) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/00-Portfolio-Package/index.html) |
| **SQL — NSE Stock Market Analysis** | HEXA Solutions | SQLite database of NSE equities with SQL queries for returns, volatility, moving averages and sector comparisons. | Reusable SQL query bank + SQLite DB | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/07-SQL-NSE-Stock-Market) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/07-SQL-NSE-Stock-Market/index.html) |
| **Tennis SportRadar API Pipeline** | HEXA Solutions | API ingestion → SQLite → Streamlit app for competitions, rankings and venues. | Working API-to-app pipeline (Streamlit) | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/12-Tennis-SportRadar-API-Pipeline) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/12-Tennis-SportRadar-API-Pipeline/index.html) |

[← By Skills](../README.md) · [← Lens dashboard](../../README.md)