# Skills: Digital marketing

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Digital Marketing — EcoStyle Facebook Ads Campaign** | Internship Studio | Campaign workbook, 5 ad creatives and 12-page report for a fashion brand. | Base case 181 purchases, ₹2.72 L revenue, ROAS 4.53×, CPA ₹331, +23.5% sales | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/16-EcoStyle-Facebook-Ads-Campaign-Plan) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/16-EcoStyle-Facebook-Ads-Campaign-Plan/index.html) |

[← By Skills](../README.md) · [← Lens dashboard](../../README.md)