# Skills: Market sizing & competitive analysis

2 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **B2B SaaS Strategy — AI Customer Operations Platform** | Product Management | Evolving a support chatbot into an AI Customer Operations Platform vs Intercom/Zendesk/Freshdesk/Salesforce — segment, market sizing, core problem, moats, land-and-expand. | 11-sheet / 211-formula justification workbook, CFO ROI 8.4×, 36-cell sensitivity grid | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/02-Product-Management-Case-Studies/02-AI-Customer-Operations-Platform-B2B-SaaS) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/02-Product-Management-Case-Studies/02-AI-Customer-Operations-Platform-B2B-SaaS/index.html) |
| **Uber — Proactive Pickup Guidance** | Product Management | Should Uber guide riders to better pickup points in dense areas? Market research + competitive analysis, Five Forces, TAM/SAM/SOM, interview toolkit and 8-sheet workbook with pivots. | 14-page master, 11-slide zero-white-space deck | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/02-Product-Management-Case-Studies/03-Uber-Pickup-Coordination) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/02-Product-Management-Case-Studies/03-Uber-Pickup-Coordination/index.html) |

[← By Skills](../README.md) · [← Lens dashboard](../../README.md)