# By Skills

Capabilities demonstrated. 30 values across 83 projects.

| Skills | Projects | Folder |
|---|:-:|---|
| [API & data pipelines](API-data-pipelines/) | 6 | [`API-data-pipelines/`](API-data-pipelines/) |
| [C++ & data structures](C-data-structures/) | 1 | [`C-data-structures/`](C-data-structures/) |
| [CAD & engineering drawing](CAD-engineering-drawing/) | 1 | [`CAD-engineering-drawing/`](CAD-engineering-drawing/) |
| [Cloud deployment](Cloud-deployment/) | 4 | [`Cloud-deployment/`](Cloud-deployment/) |
| [Dashboard design](Dashboard-design/) | 12 | [`Dashboard-design/`](Dashboard-design/) |
| [Data visualisation](Data-visualisation/) | 11 | [`Data-visualisation/`](Data-visualisation/) |
| [Digital marketing](Digital-marketing/) | 1 | [`Digital-marketing/`](Digital-marketing/) |
| [Embedded / firmware](Embedded-firmware/) | 5 | [`Embedded-firmware/`](Embedded-firmware/) |
| [Energy auditing](Energy-auditing/) | 2 | [`Energy-auditing/`](Energy-auditing/) |
| [Excel modelling & formulas](Excel-modelling-formulas/) | 20 | [`Excel-modelling-formulas/`](Excel-modelling-formulas/) |
| [Exploratory data analysis](Exploratory-data-analysis/) | 7 | [`Exploratory-data-analysis/`](Exploratory-data-analysis/) |
| [Financial analysis](Financial-analysis/) | 9 | [`Financial-analysis/`](Financial-analysis/) |
| [Graphic & vector design](Graphic-vector-design/) | 7 | [`Graphic-vector-design/`](Graphic-vector-design/) |
| [HR policy & people ops](HR-policy-people-ops/) | 4 | [`HR-policy-people-ops/`](HR-policy-people-ops/) |
| [Machine learning](Machine-learning/) | 8 | [`Machine-learning/`](Machine-learning/) |
| [Market sizing & competitive analysis](Market-sizing-competitive-analysis/) | 2 | [`Market-sizing-competitive-analysis/`](Market-sizing-competitive-analysis/) |
| [PRD & product specification](PRD-product-specification/) | 1 | [`PRD-product-specification/`](PRD-product-specification/) |
| [Presentation & storytelling](Presentation-storytelling/) | 7 | [`Presentation-storytelling/`](Presentation-storytelling/) |
| [Prioritisation frameworks (RICE etc.)](Prioritisation-frameworks-RICE-etc/) | 3 | [`Prioritisation-frameworks-RICE-etc/`](Prioritisation-frameworks-RICE-etc/) |
| [Product strategy](Product-strategy/) | 5 | [`Product-strategy/`](Product-strategy/) |
| [Python programming](Python-programming/) | 48 | [`Python-programming/`](Python-programming/) |
| [SQL & databases](SQL-databases/) | 3 | [`SQL-databases/`](SQL-databases/) |
| [Security analysis (defensive)](Security-analysis-defensive/) | 20 | [`Security-analysis-defensive/`](Security-analysis-defensive/) |
| [Simulation & modelling](Simulation-modelling/) | 7 | [`Simulation-modelling/`](Simulation-modelling/) |
| [Software testing & QA](Software-testing-QA/) | 4 | [`Software-testing-QA/`](Software-testing-QA/) |
| [Statistics & correlation](Statistics-correlation/) | 4 | [`Statistics-correlation/`](Statistics-correlation/) |
| [Structural design](Structural-design/) | 1 | [`Structural-design/`](Structural-design/) |
| [Technical writing & documentation](Technical-writing-documentation/) | 26 | [`Technical-writing-documentation/`](Technical-writing-documentation/) |
| [User research & interviews](User-research-interviews/) | 5 | [`User-research-interviews/`](User-research-interviews/) |
| [Web development](Web-development/) | 17 | [`Web-development/`](Web-development/) |

[← Lens dashboard](../README.md)