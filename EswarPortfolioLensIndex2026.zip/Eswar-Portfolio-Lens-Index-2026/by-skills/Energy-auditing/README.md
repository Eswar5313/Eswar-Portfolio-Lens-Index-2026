# Skills: Energy auditing

2 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Textile Mill — HT Electricity Bill Energy Audit** | Internship Studio | Bill reconstruction, TOD/PF/MD analysis and savings measures (APFC, demand controller, TOD shift, IE3+VFD, LED). | Annual bill ₹10.76 Cr @ ₹10.26/kWh; savings ₹81.9 L = 7.6% | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/05-Textile-Electricity-Bill-Energy-Audit) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/05-Textile-Electricity-Bill-Energy-Audit/index.html) |
| **EV 05 — EV Drivetrain Modeling** | Codec Technologies | Motor/inverter/gear drivetrain model with drive-cycle simulation (Python equivalent of MATLAB brief). | Drive-cycle energy results + tests | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/04-Codec-Technologies-EV-and-Cyber/EV-05-Drivetrain-Modeling) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/04-Codec-Technologies-EV-and-Cyber/EV-05-Drivetrain-Modeling/index.html) |

[← By Skills](../README.md) · [← Lens dashboard](../../README.md)