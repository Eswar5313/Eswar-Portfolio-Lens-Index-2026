import os, re, json, shutil, html
from registry import TRACKS, REPO_NAME as MASTER, OWNER, HANDLE

REPO = "Eswar-Portfolio-Lens-Index-2026"
OUT = f"/home/claude/out/{REPO}"
GH_MASTER = f"https://github.com/{HANDLE}/{MASTER}/tree/main"
PAGES = f"https://{HANDLE}.github.io/{REPO}"
MASTER_PAGES = f"https://{HANDLE}.github.io/{MASTER}"
if os.path.exists(OUT): shutil.rmtree(OUT)
os.makedirs(OUT)
esc = lambda s: html.escape(str(s))
slug = lambda s: re.sub(r"[^A-Za-z0-9]+", "-", s).strip("-")

# ------------------------------------------------------------ classification rules
def has(p, *words):
    blob = (p["title"] + " " + p["summary"] + " " + " ".join(p["tags"]) + " " + " ".join(p["tools"]) + " " + " ".join(p["results"])).lower()
    return any(re.search(r"(?<![A-Za-z0-9])"+re.escape(w.lower())+r"(?![A-Za-z0-9])", blob) for w in words)

def domain(tr, p):
    if tr["key"] == "hexa" or has(p, "EDA", "Data Science", "Statistics"): return "Data Analytics & Science"
    if tr["key"] == "pm" or has(p, "Product", "PRD"): return "Product Management & Strategy"
    if has(p, "Cyber", "Security"): return "Cyber Security (Defensive)"
    if has(p, "EV", "IoT", "Embedded", "Drivetrain", "Charging"): return "Electric Vehicles & Embedded Engineering"
    if has(p, "Excel", "Finance", "Energy"): return "Finance, Energy & Excel Modelling"
    if has(p, "Civil", "AutoCAD", "Structures"): return "Civil & CAD Engineering"
    if has(p, "HR", "Psychology", "Policy"): return "HR & Organisational Psychology"
    if has(p, "Marketing", "Illustrator", "Design", "Brand", "Blog"): return "Design, Marketing & Content"
    if has(p, "Web", "Tool", "JavaScript", "Cloud", "AWS", "C++", "DSA", "Software Testing", "ML", "AI"): return "Software, Cloud & Web"
    return "Documentation & Assessments"

SKILL_RULES = [
 ("Python programming", ["Python","pandas","Jupyter","Notebook"]), ("SQL & databases", ["SQL","SQLite"]),
 ("Machine learning", ["ML","scikit-learn","RandomForest","Ridge","GradientBoosting","Regression","classifier","IDS"]),
 ("Exploratory data analysis", ["EDA","Exploratory"]), ("Statistics & correlation", ["Statistics","correlation","scipy","regression"]),
 ("Excel modelling & formulas", ["Excel","formulas","workbook","VLOOKUP","pivot"]), ("Dashboard design", ["Dashboard","Chart.js","Plotly","Tableau"]),
 ("Data visualisation", ["matplotlib","seaborn","Plotly","Tableau","charts"]), ("API & data pipelines", ["API","pipeline","ingestion"]),
 ("Product strategy", ["Strategy","moats","land-and-expand","roadmap"]), ("User research & interviews", ["interview","user research","UX","exploration"]),
 ("PRD & product specification", ["PRD","spec","flowchart","wireframe"]), ("Market sizing & competitive analysis", ["market sizing","TAM","Five Forces","competitive"]),
 ("Prioritisation frameworks (RICE etc.)", ["RICE","prioritis","APFD"]), ("Financial analysis", ["Finance","ratio","D/E","ROI","revenue","budget"]),
 ("Simulation & modelling", ["Simulation","simulator","model"]), ("Embedded / firmware", ["Arduino","ESP8266","firmware","Embedded","IoT"]),
 ("Security analysis (defensive)", ["Cyber","Security","phishing","IDS","ransomware","threat"]), ("Software testing & QA", ["Software Testing","Playwright","Jest","valgrind","test suite"]),
 ("Web development", ["HTML","CSS","JavaScript","JS","Web","Next.js","React"]), ("Cloud deployment", ["AWS","EC2","S3","Netlify","Vercel","Cloud Run"]),
 ("CAD & engineering drawing", ["AutoCAD","DXF","drawing"]), ("Structural design", ["RCC","IS 456","slab","column"]), ("Energy auditing", ["Energy","electricity","TOD","kWh"]),
 ("HR policy & people ops", ["HR","onboarding","policy","engagement","wellbeing"]), ("Digital marketing", ["Marketing","Ads","campaign","ROAS"]),
 ("Graphic & vector design", ["Illustrator","SVG","Design","icon"]), ("Technical writing & documentation", ["report","PDF","Docs","README","book"]),
 ("Presentation & storytelling", ["PPTX","deck","Presentation","slides"]), ("C++ & data structures", ["C++","DSA","linked list"]),
]
def skills(p): return [s for s, ws in SKILL_RULES if has(p, *ws)]

SECTOR_RULES = [
 ("Logistics & Supply Chain", ["FedEx","Supply Chain","shipment","SKU","dark-store","warehouse"]), ("E-commerce & Quick-commerce", ["Flipkart","Amazon","Zepto","Blinkit","Quick-commerce","Nykaa","cart","E-Commerce","grocery"]),
 ("Mobility & Ride-hailing", ["Uber","Mobility","pickup","ride"]), ("Automotive & Electric Vehicles", ["EV","Electric","Battery","Charging","Drivetrain","Tata Motors"]),
 ("Fintech & Financial Services", ["Finance","NSE","Stock","ratio","fintech","InvestMyFunds","Ledger","budget"]), ("Real Estate", ["Dubai","Airbnb","Real Estate","property"]),
 ("Health, Fitness & Wellbeing", ["Health","Fitness","Strava","VitaFit","Mental Health","wellbeing","Psychology"]), ("Media, Gaming & Entertainment", ["Prime","Video Game","Media","Tennis","Sport"]),
 ("Food & Hospitality", ["Zomato","Food","Hospitality","Café"]), ("IT, SaaS & AI Products", ["SaaS","AI","chatbot","Customer Operations","Product Management","Software"]),
 ("Cyber Security", ["Cyber","Security","phishing","IDS"]), ("Manufacturing, Energy & Utilities", ["Textile","Energy","Predictive Maintenance","IoT","electricity","Solar","Wireless"]),
 ("Construction & Infrastructure", ["RCC","Civil","AutoCAD","Structural","Traffic"]), ("Education & EdTech", ["Student","Exam","Proctoring","Library","Learning","lesson"]),
 ("HR & Corporate Services", ["HR","onboarding","TechX","policy"]), ("Retail & Consumer Brands", ["EcoStyle","Fashion","Retail","Sales Dashboard","Multi-Region"]),
 ("Cloud & DevOps", ["AWS","EC2","ROS","Cloud"]), ("Career & Personal Branding", ["Career","Portfolio","Application Engine","Blog","Profile","Journal","Register","Assessments"]),
]
def sectors(p): return [s for s, ws in SECTOR_RULES if has(p, *ws)] or ["Cross-industry"]

ROLE_RULES = [
 ("Data Analyst / BI Analyst", ["EDA","Dashboard","Excel","SQL","Statistics","Data"]), ("Data Scientist / ML Engineer", ["ML","scikit-learn","RandomForest","classifier","Regression","AI"]),
 ("Product Manager / APM", ["Product","PRD","RICE","Strategy","UX","interview"]), ("Business / Strategy Analyst", ["Strategy","market","roadmap","Finance","ratio","ROI","case"]),
 ("Supply Chain / Operations Manager", ["Supply Chain","FedEx","SKU","logistics","Ops","warehouse","replenishment"]), ("Security Analyst (SOC / Blue Team)", ["Cyber","Security","IDS","phishing","threat"]),
 ("EV / Embedded / Electrical Engineer", ["EV","Battery","firmware","Arduino","ESP8266","Drivetrain","Charging","Wireless","Energy"]), ("Software / Web Developer", ["HTML","JavaScript","React","C++","Node.js","Web","app"]),
 ("Cloud / DevOps Engineer", ["AWS","EC2","S3","ROS","Netlify","Vercel"]), ("Civil / Structural Engineer", ["RCC","Civil","AutoCAD","slab"]),
 ("HR / People Operations", ["HR","onboarding","engagement","wellbeing","Psychology"]), ("Marketing / Growth Manager", ["Marketing","Ads","ROAS","Brand","Blog","Growth","AOV"]),
 ("Designer (UX / Graphic)", ["Illustrator","SVG","wireframe","Figma","UX","Design"]), ("QA / Test Engineer", ["Software Testing","APFD","Playwright","Jest","valgrind"]),
]
def roles(p): return [r for r, ws in ROLE_RULES if has(p, *ws)]

DELIV_RULES = [("PDF report", ["pdf","report"]), ("Excel workbook (live formulas)", ["xlsx","workbook","Excel"]), ("Presentation deck", ["pptx","deck","Presentation"]),
 ("Code / notebook", ["ipynb","py","src/","app","cpp","script","notebook","tests/"]), ("Interactive dashboard", ["dashboard","html","Dash"]), ("Web app / site", ["index.html","site/","app/","Web"]),
 ("Drawings / vector artwork", ["dxf","svg","drawing","creatives"]), ("Video / Loom", ["Loom","mp4","video"]), ("Dataset", ["csv","db","data"])]
def delivs(p):
    blob = (" ".join(p["files"]) + " " + " ".join(p["tools"]) + " " + p["summary"]).lower()
    return [d for d, ws in DELIV_RULES if any(re.search(r"(?<![A-Za-z0-9])"+re.escape(w.lower())+r"(?![A-Za-z0-9])", blob) for w in ws)]

METHOD_RULES = [("Exploratory data analysis", ["EDA"]), ("Regression modelling", ["Regression","Ridge","GradientBoosting","price model"]), ("Classification (RandomForest etc.)", ["RandomForest","classifier","IDS","balanced"]),
 ("Rolling-window feature engineering", ["rolling"]), ("Extended Kalman Filter", ["EKF"]), ("Correlation analysis", ["correlation"]), ("Pivot / cross-tab analysis", ["pivot","COUNTIFS","SUMIFS","cross-tab"]),
 ("Lookup modelling (VLOOKUP/INDEX-MATCH)", ["VLOOKUP","INDEX"]), ("Forecasting (moving average, logistic, Bass)", ["Forecast","moving average","logistic","Bass","CAGR"]), ("RICE prioritisation", ["RICE"]),
 ("Severity × Frequency matrix", ["Severity"]), ("JTBD / Five Whys / Double Diamond", ["JTBD","Five Whys"]), ("Porter's Five Forces", ["Five Forces"]), ("TAM / SAM / SOM sizing", ["TAM","SAM","market sizing"]),
 ("STP segmentation", ["segment","STP"]), ("Holdout / A-B experiment design", ["holdout","A/B","pilot"]), ("Difference-in-differences", ["DiD"]), ("APFD test prioritisation", ["APFD"]), ("Set-cover suite reduction", ["set-cover"]),
 ("IS 456 limit-state design", ["IS 456","slab","column","Fe415"]), ("Life-cycle assessment", ["LCA","Lifecycle"]), ("Ratio analysis & articulated statements", ["ratio","D/E","articulated"]),
 ("TOD / PF / MD tariff analysis", ["TOD","PF","tariff"]), ("ROAS / CPA campaign modelling", ["ROAS","CPA"]), ("k-anonymity", ["k-anonymity"]), ("Sensitivity analysis", ["sensitivity"]), ("Unit economics / ROI", ["ROI","unit economics","CFO"])]
def methods(p): return [m for m, ws in METHOD_RULES if has(p, *ws)]

def provenance(p):
    if has(p, "declared-synthetic", "synthetic", "substitute"): return "Declared-synthetic / substituted data"
    if has(p, "real ", "NSL-KDD", "UCI", "IEA", "NASA", "StudentsPerformance", "public", "API"): return "Real public dataset / live API"
    if has(p, "interview", "survey", "exploration"): return "Primary research (own interviews / observation)"
    if has(p, "brief", "case", "assignment", "supplied"): return "Company-supplied brief / case data"
    return "Own build (no external dataset)"

LENSES = [
 ("domain", "Domain", "What field the work belongs to", lambda tr,p: [domain(tr,p)]),
 ("skills", "Skills", "Capabilities demonstrated", lambda tr,p: skills(p)),
 ("tools", "Tools & Technologies", "Software, libraries and platforms used", lambda tr,p: p["tools"]),
 ("sector", "Sector / Industry", "Industry context of the problem", lambda tr,p: sectors(p)),
 ("role", "Target Role Fit", "Which job roles this project is evidence for", lambda tr,p: roles(p)),
 ("deliverable", "Deliverable Type", "What was actually produced", lambda tr,p: delivs(p)),
 ("method", "Methods & Frameworks", "Analytical / product / engineering methods applied", lambda tr,p: methods(p)),
 ("provenance", "Data Provenance", "Where the data came from (integrity lens)", lambda tr,p: [provenance(p)]),
 ("programme", "Programme / Organisation", "Where the work was done", lambda tr,p: [tr["org"]]),
 ("source_track", "Source Track", "Folder in the master repository", lambda tr,p: [tr["title"]]),
]

# ------------------------------------------------------------ build index
projects = []
for tr in TRACKS:
    for p in tr["projects"]:
        rec = dict(id=f"{tr['slug']}/{p['slug']}", title=p["title"], summary=p["summary"], result=(p["results"][0] if p["results"] else ""),
                   tools=p["tools"], tags=p["tags"], track=tr["title"], master_folder=f"{GH_MASTER}/{tr['slug']}/{p['slug']}",
                   master_page=f"{MASTER_PAGES}/{tr['slug']}/{p['slug']}/index.html")
        for key, name, _, fn in LENSES: rec[key] = fn(tr, p)
        projects.append(rec)
N = len(projects)
lens_values = {key: sorted({v for r in projects for v in r[key]}) for key,_,_,_ in LENSES}
json.dump(dict(repo=REPO, master=MASTER, total=N, lenses=[dict(key=k,name=n,desc=d,values=lens_values[k]) for k,n,d,_ in LENSES], projects=projects), open(f"{OUT}/lens_index.json","w"), indent=2, ensure_ascii=False)
# matrix csv
import csv
with open(f"{OUT}/project_lens_matrix.csv","w",newline="") as f:
    w = csv.writer(f); w.writerow(["id","title","track"]+[n for _,n,_,_ in LENSES])
    for r in projects: w.writerow([r["id"],r["title"],r["track"]]+["; ".join(r[k]) for k,_,_,_ in LENSES])

# ------------------------------------------------------------ HTML
CSS = open("/home/claude/build/generate.py").read().split('CSS = """')[1].split('"""')[0]
FONTS = '<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@500;600;700&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">'
EXTRA = """.lens{display:flex;flex-wrap:wrap;gap:8px}.lens .chip{font-weight:600}.grp{margin:26px 0}.grp h2{font-size:22px;color:var(--navy);border-left:5px solid var(--gold);padding-left:12px;margin-bottom:12px}.grp .n{font-size:13px;color:var(--muted);font-weight:400;margin-left:8px}
.card .meta{font-size:11.5px;color:var(--muted)}.matrix{overflow-x:auto}.matrix table{border-collapse:collapse;font-size:12.5px;width:100%}.matrix th,.matrix td{border:1px solid var(--line);padding:6px 8px;text-align:left;vertical-align:top;background:#fff}.matrix th{background:var(--navy);color:#fff;position:sticky;top:0}"""
def page(title, body):
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)}</title>{FONTS}<style>{CSS}{EXTRA}</style></head><body>{body}
<div class="foot"><div class="wrap">© 2026 {OWNER} · Lens index over the <a href="https://github.com/{HANDLE}/{MASTER}">Master Project Portfolio</a> — every card links to the project folder that holds its files.</div></div></body></html>"""

def card_html(r):
    return f"""<article class="card" data-id="{esc(r['id'])}"><div class="id">{esc(r['track'].split(' — ')[0])}</div><h3>{esc(r['title'])}</h3><p>{esc(r['summary'])}</p>{f'<div class="res">▸ {esc(r["result"])}</div>' if r['result'] else ''}
<div class="meta">{esc(' · '.join(r['sector']))}</div><div class="tags">{''.join(f'<span>{esc(t)}</span>' for t in r['tools'][:5])}</div><a class="go" href="{r['master_page']}" aria-label="Open"></a></article>"""

lens_chips = ''.join(f'<button class="chip{" on" if i==0 else ""}" data-lens="{k}">{esc(n)}</button>' for i,(k,n,_,_) in enumerate(LENSES))
root = f"""<header class="top"><div class="wrap"><div class="crumb">Portfolio Lens Index · 2026</div><h1>{OWNER} — Portfolio by Domain, Skills, Tools &amp; Sector</h1>
<p class="lead">The same {N} projects from the master repository, re-indexed through {len(LENSES)} lenses so a hiring manager can start from what they are hiring for — a skill, a tool, an industry, a role — and land on the evidence in three clicks.</p>
<div class="kpis"><div class="kpi"><b>{N}</b><span>Projects</span></div><div class="kpi"><b>{len(LENSES)}</b><span>Lenses</span></div><div class="kpi"><b>{len(lens_values['skills'])}</b><span>Skills</span></div><div class="kpi"><b>{len(lens_values['tools'])}</b><span>Tools</span></div><div class="kpi"><b>{len(lens_values['sector'])}</b><span>Sectors</span></div><div class="kpi"><b>{len(lens_values['role'])}</b><span>Target roles</span></div><div class="kpi"><b>{len(lens_values['method'])}</b><span>Methods</span></div></div>
<div class="btnrow"><a class="btn" href="https://github.com/{HANDLE}/{MASTER}">Master repository (files)</a><a class="btn ghost" href="README.md">README</a><a class="btn ghost" href="matrix.html">Full matrix</a></div></div></header>
<div class="bar"><div class="wrap"><input id="q" type="search" placeholder="Search a skill, tool, sector, method, role…"><div class="lens">{lens_chips}</div><span style="font-size:13px;color:var(--muted)">Showing <b id="count"></b></span></div></div>
<main><div class="wrap" id="root"></div></main>
<script>const DATA={json.dumps(projects, ensure_ascii=False)};const LENSES={json.dumps([[k,n] for k,n,_,_ in LENSES])};
const CARDS={{}};{'{'}const tpl=document.createElement('div');{'}'}
function cardHTML(r){{return `<article class="card"><div class="id">${{r.track.split(' — ')[0]}}</div><h3>${{r.title}}</h3><p>${{r.summary}}</p>${{r.result?`<div class="res">▸ ${{r.result}}</div>`:''}}<div class="meta">${{r.sector.join(' · ')}}</div><div class="tags">${{r.tools.slice(0,5).map(t=>`<span>${{t}}</span>`).join('')}}</div><a class="go" href="${{r.master_page}}"></a></article>`}}
let lens='domain';const q=document.getElementById('q');
function render(){{const s=q.value.trim().toLowerCase();const groups={{}};let shown=0;
DATA.forEach(r=>{{const blob=(r.title+' '+r.summary+' '+r.tools.join(' ')+' '+LENSES.map(l=>r[l[0]].join(' ')).join(' ')).toLowerCase();if(s&&!blob.includes(s))return;shown++;(r[lens].length?r[lens]:['(unclassified)']).forEach(v=>{{(groups[v]=groups[v]||[]).push(r)}})}});
const keys=Object.keys(groups).sort((a,b)=>groups[b].length-groups[a].length||a.localeCompare(b));
document.getElementById('root').innerHTML=keys.length?keys.map(k=>`<section class="grp"><h2>${{k}}<span class="n">${{groups[k].length}} project${{groups[k].length>1?'s':''}}</span></h2><div class="grid">${{groups[k].map(cardHTML).join('')}}</div></section>`).join(''):'<div class="empty">No projects match.</div>';
document.getElementById('count').textContent=shown;}}
document.querySelectorAll('.chip').forEach(b=>b.onclick=()=>{{lens=b.dataset.lens;document.querySelectorAll('.chip').forEach(x=>x.classList.toggle('on',x===b));render();}});q.oninput=render;render();</script>"""
open(f"{OUT}/index.html","w").write(page(f"{OWNER} — Portfolio Lens Index", root))
open(f"{OUT}/.nojekyll","w").write("")

# matrix page
th = "".join(f"<th>{esc(n)}</th>" for _,n,_,_ in LENSES)
rows = "".join(f"<tr><td><a href='{r['master_page']}'><b>{esc(r['title'])}</b></a></td>" + "".join(f"<td>{esc('; '.join(r[k]))}</td>" for k,_,_,_ in LENSES) + "</tr>" for r in projects)
open(f"{OUT}/matrix.html","w").write(page("Project × Lens matrix", f"""<header class="top"><div class="wrap"><div class="crumb"><a href="index.html">← Lens dashboard</a></div><h1>Project × Lens matrix</h1><p class="lead">All {N} projects against all {len(LENSES)} lenses. Also available as <code>project_lens_matrix.csv</code> and <code>lens_index.json</code>.</p></div></header><main><div class="wrap matrix"><table><thead><tr><th>Project</th>{th}</tr></thead><tbody>{rows}</tbody></table></div></main>"""))

# per-lens folders: README + index.html per value
for key, name, desc, _ in LENSES:
    ld = f"{OUT}/by-{key}"; os.makedirs(ld)
    vals = lens_values[key]
    lines = [f"# By {name}\n", f"{desc}. {len(vals)} values across {N} projects.\n", "| {} | Projects | Folder |".format(name), "|---|:-:|---|"]
    cards_all = ""
    for v in vals:
        vs = slug(v); vd = f"{ld}/{vs}"; os.makedirs(vd)
        rs = [r for r in projects if v in r[key]]
        lines.append(f"| [{v}]({vs}/) | {len(rs)} | [`{vs}/`]({vs}/) |")
        plines = [f"# {name}: {v}\n", f"{len(rs)} projects. Each link opens the project folder in the master repository.\n", "| Project | Track | What it is | Headline result | Files |", "|---|---|---|---|---|"]
        for r in rs: plines.append(f"| **{r['title']}** | {r['track'].split(' — ')[0]} | {r['summary']} | {r['result']} | [folder]({r['master_folder']}) · [page]({r['master_page']}) |")
        plines.append(f"\n[← By {name}](../README.md) · [← Lens dashboard](../../README.md)")
        open(f"{vd}/README.md","w").write("\n".join(plines))
        open(f"{vd}/index.html","w").write(page(f"{name}: {v}", f"""<header class="top"><div class="wrap"><div class="crumb"><a href="../../index.html">← Lens dashboard</a> / <a href="../index.html">By {esc(name)}</a></div><h1>{esc(v)}</h1><p class="lead">{len(rs)} projects · lens: {esc(name)}</p></div></header><main><div class="wrap"><div class="grid">{''.join(card_html(r) for r in rs)}</div></div></main>"""))
        cards_all += f"""<article class="card"><div class="id">{esc(name)}</div><h3>{esc(v)}</h3><p>{len(rs)} project{'s' if len(rs)>1 else ''}</p><div class="tags">{''.join(f'<span>{esc(r["title"][:28])}</span>' for r in rs[:4])}</div><a class="go" href="{vs}/index.html"></a></article>"""
    lines.append("\n[← Lens dashboard](../README.md)")
    open(f"{ld}/README.md","w").write("\n".join(lines))
    open(f"{ld}/index.html","w").write(page(f"By {name}", f"""<header class="top"><div class="wrap"><div class="crumb"><a href="../index.html">← Lens dashboard</a></div><h1>By {esc(name)}</h1><p class="lead">{esc(desc)} · {len(vals)} values</p></div></header><main><div class="wrap"><div class="grid">{cards_all}</div></div></main>"""))

# ------------------------------------------------------------ README dashboard
def badge(l,m,c,logo=""): return f"![](https://img.shields.io/badge/{l.replace(' ','%20').replace('-','--')}-{m.replace(' ','%20').replace('-','--')}-{c}?style=for-the-badge{('&logo='+logo+'&logoColor=C9A227') if logo else ''})"
R = [f"""<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:C9A227,50:132B5C,100:0A1F44&height=190&section=header&text=Eswar%20Mahalingam&fontSize=46&fontColor=ffffff&fontAlignY=38&desc=Portfolio%20Lens%20Index%20%E2%80%A2%20{N}%20projects%20%C3%97%20{len(LENSES)}%20lenses&descAlignY=60&descSize=17&descColor=E4C56A" width="100%"/>

{badge("Projects",str(N),"0A1F44","githubactions")} {badge("Lenses",str(len(LENSES)),"C9A227")} {badge("Skills",str(len(lens_values['skills'])),"0A1F44")} {badge("Tools",str(len(lens_values['tools'])),"C9A227")} {badge("Sectors",str(len(lens_values['sector'])),"0A1F44")} {badge("Target roles",str(len(lens_values['role'])),"C9A227")} {badge("Methods",str(len(lens_values['method'])),"0A1F44")}

[![Live lens dashboard](https://img.shields.io/badge/%E2%96%B6%20OPEN%20LENS%20DASHBOARD-C9A227?style=for-the-badge)]({PAGES}/)
[![Master repo](https://img.shields.io/badge/Master%20repo-all%20files-0A1F44?style=for-the-badge&logo=github&logoColor=C9A227)](https://github.com/{HANDLE}/{MASTER})
[![LinkedIn](https://img.shields.io/badge/LinkedIn-eswar--mahalingam-0A66C2?style=for-the-badge&logo=linkedin)](https://linkedin.com/in/eswar-mahalingam)

</div>

> **Start from what you are hiring for.** Pick a lens below — a skill, a tool, an industry, a target role, a method — and every project that proves it is listed with a direct link to its folder (PDF report, Excel workbook, deck, code) in the [master repository](https://github.com/{HANDLE}/{MASTER}).

## 🔍 Choose a lens

<table>"""]
tiles = [f"""<td align="center" width="20%"><a href="by-{k}/"><img src="https://img.shields.io/badge/{esc(n).replace(' ','%20').replace('-','--').replace('&','%26').replace('/','%2F')}-{len(lens_values[k])}-C9A227?style=for-the-badge&labelColor=0A1F44"/></a><br><sub>{esc(d)}</sub></td>""" for k,n,d,_ in LENSES]
for i in range(0,len(tiles),5): R.append("<tr>\n"+"\n".join(tiles[i:i+5])+"\n</tr>")
R.append("</table>\n")
for key, name, desc, _ in LENSES:
    vals = lens_values[key]
    R.append(f"""<details{' open' if key in ('domain','skills') else ''}>
<summary><b>By {name}</b> — {len(vals)} values · <i>{desc}</i></summary>

<br>

| {name} | Projects | Examples |
|---|:-:|---|""")
    for v in sorted(vals, key=lambda v: -len([r for r in projects if v in r[key]])):
        rs = [r for r in projects if v in r[key]]
        ex = ", ".join(f"[{r['title'][:40]}]({r['master_folder']})" for r in rs[:3]) + (f" … +{len(rs)-3}" if len(rs)>3 else "")
        R.append(f"| [**{v}**](by-{key}/{slug(v)}/) | {len(rs)} | {ex} |")
    R.append(f"\n[Open lens folder →](by-{key}/)\n\n</details>\n")
R.append(f"""## 🗂️ What is in this repository

| Path | Purpose |
|---|---|
| `index.html` | Interactive lens dashboard — switch lens, search, click through to project folders |
| `matrix.html` · `project_lens_matrix.csv` · `lens_index.json` | Every project against every lens (web, spreadsheet, machine-readable) |
| `by-domain/ by-skills/ by-tools/ by-sector/ by-role/ by-deliverable/ by-method/ by-provenance/ by-programme/ by-source_track/` | One folder per lens; one sub-folder per value with its own README + page |

The files themselves (PDFs, workbooks, decks, code) live in **[{MASTER}](https://github.com/{HANDLE}/{MASTER})** — this repository is the index that lets you approach them from any angle.

<div align="center">

**{OWNER}** · Ghaziabad, NCR, India · MBA · CSCMP SCPro · Six Sigma Black Belt<br>
[LinkedIn](https://linkedin.com/in/eswar-mahalingam) · eswarmba05313@gmail.com · +91-9360548243

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:0A1F44,100:C9A227&height=100&section=footer" width="100%"/>

</div>
""")
open(f"{OUT}/README.md","w").write("\n".join(R))

DESC = (f"Skills-first index of my {N}-project portfolio: the same work viewed by domain, skill, tool, sector/industry, target role, deliverable type, method, "
        "data provenance and programme. Pick what you are hiring for and land on the evidence — every entry links to its PDF, Excel, deck and code in the master repo.")
assert len(DESC) <= 350, len(DESC)
open(f"{OUT}/REPO_NAME_AND_DESCRIPTION.txt","w").write(f"""REPOSITORY NAME
{REPO}

DESCRIPTION ({len(DESC)}/350 characters)
{DESC}

TOPICS
portfolio skills-matrix data-analytics product-management excel python machine-learning cyber-security electric-vehicles industry-index career

WEBSITE (after enabling GitHub Pages)
{PAGES}/
""")
open(f"{OUT}/PUSH_TO_GITHUB.md","w").write(f"""# Push
1. Replace `{HANDLE}` with your GitHub username everywhere: `grep -rl "{HANDLE}" . | xargs sed -i 's/{HANDLE}/<your-username>/g'`
2. Create repo **{REPO}** on GitHub (description in `REPO_NAME_AND_DESCRIPTION.txt`), then:
```bash
git init && git add . && git commit -m "Portfolio lens index: {N} projects x {len(LENSES)} lenses" && git branch -M main
git remote add origin https://github.com/<your-username>/{REPO}.git && git push -u origin main
```
3. Settings → Pages → main / root → the dashboard is live at `{PAGES}/`.
4. This repo links into `{MASTER}`; push that one first so every link resolves.
""")
shutil.copy("/home/claude/build/lens.py", f"{OUT}/_build_lens.py")
print(N, {k:len(v) for k,v in lens_values.items()}, len(DESC))
