# By Data Provenance

Where the data came from (integrity lens). 5 values across 83 projects.

| Data Provenance | Projects | Folder |
|---|:-:|---|
| [Company-supplied brief / case data](Company-supplied-brief-case-data/) | 11 | [`Company-supplied-brief-case-data/`](Company-supplied-brief-case-data/) |
| [Declared-synthetic / substituted data](Declared-synthetic-substituted-data/) | 7 | [`Declared-synthetic-substituted-data/`](Declared-synthetic-substituted-data/) |
| [Own build (no external dataset)](Own-build-no-external-dataset/) | 54 | [`Own-build-no-external-dataset/`](Own-build-no-external-dataset/) |
| [Primary research (own interviews / observation)](Primary-research-own-interviews-observation/) | 5 | [`Primary-research-own-interviews-observation/`](Primary-research-own-interviews-observation/) |
| [Real public dataset / live API](Real-public-dataset-live-API/) | 6 | [`Real-public-dataset-live-API/`](Real-public-dataset-live-API/) |

[← Lens dashboard](../README.md)