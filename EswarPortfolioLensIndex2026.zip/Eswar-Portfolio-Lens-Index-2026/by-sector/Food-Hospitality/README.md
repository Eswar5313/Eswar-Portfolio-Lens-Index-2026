# Sector / Industry: Food & Hospitality

3 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Zomato Restaurant EDA** | HEXA Solutions | Restaurant ratings, cuisines, cost-for-two and online-order behaviour analysed by city/locality. | Cuisine × price × rating patterns | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/04-Zomato-Restaurant-EDA) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/04-Zomato-Restaurant-EDA/index.html) |
| **Airbnb Listings Dashboard** | HEXA Solutions | Listing prices, availability, room types and neighbourhood analysis presented as a dashboard. | Price and availability heat-map by neighbourhood | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/09-Airbnb-Dashboard) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/09-Airbnb-Dashboard/index.html) |
| **Adobe Illustrator — Vector Design Portfolio** | Internship Studio | 34 original SVGs: icon set, tee graphic, poster series, patterns, mascot family, café social kit, 3D lettering; 10-page portfolio PDF. | 34 originals, no stock or copied art | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/15-Illustrator-Vector-Design-Portfolio) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/15-Illustrator-Vector-Design-Portfolio/index.html) |

[← By Sector / Industry](../README.md) · [← Lens dashboard](../../README.md)