# Sector / Industry: Mobility & Ride-hailing

3 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Uber Supply–Demand Gap** | HEXA Solutions | Request/cancellation/no-car patterns by hour and pickup point to locate the supply gap. | Hour-band supply-gap diagnosis | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/11-Uber-Supply-Demand-Gap) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/11-Uber-Supply-Demand-Gap/index.html) |
| **Uber — Proactive Pickup Guidance** | Product Management | Should Uber guide riders to better pickup points in dense areas? Market research + competitive analysis, Five Forces, TAM/SAM/SOM, interview toolkit and 8-sheet workbook with pivots. | 14-page master, 11-slide zero-white-space deck | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/02-Product-Management-Case-Studies/03-Uber-Pickup-Coordination) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/02-Product-Management-Case-Studies/03-Uber-Pickup-Coordination/index.html) |
| **Pickup Notebook — Case-Study Blog** | Personal Builds | 10-page blog from the Uber pickup case: 7 essays + Workbench craft notes. | Netlify deploy, relative cross-links | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/06-Personal-Builds-and-Sites/07-Pickup-Notebook-Blog) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/06-Personal-Builds-and-Sites/07-Pickup-Notebook-Blog/index.html) |

[← By Sector / Industry](../README.md) · [← Lens dashboard](../../README.md)