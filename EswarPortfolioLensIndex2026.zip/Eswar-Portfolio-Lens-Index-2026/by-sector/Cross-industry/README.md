# Sector / Industry: Cross-industry

3 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Assignment 1 — Data Exploration** | Data Analytics Module 1 | Dataset + one sheet per question Q1–Q5 + summary dashboard; every sheet carries a STEP-BY-STEP METHOD block with the exact formula. | 34 products, total $10,100, avg $297.06; 758 live formulas | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/05-Excel-Data-Analytics-Module/01-Data-Exploration) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/05-Excel-Data-Analytics-Module/01-Data-Exploration/index.html) |
| **Assignment 3 — Advanced Analysis** | Data Analytics Module 1 | VLOOKUP/HLOOKUP/INDEX-MATCH, 5 pivot cross-tabs, 6 charts, forecasting/trend, interactive dashboard with 3 drop-downs. | 1,497 formulas, 0 errors; dashboard tested on 3 filter combinations | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/05-Excel-Data-Analytics-Module/03-Advanced-Analysis-Lookups-Pivots-Dashboard) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/05-Excel-Data-Analytics-Module/03-Advanced-Analysis-Lookups-Pivots-Dashboard/index.html) |
| **All-in-One Workbook + Submission Package** | Data Analytics Module 1 | 28-sheet merged workbook with clickable index, cover PDF with coverage matrix, 41-page complete submission PDF. | 5,149 formulas, 0 errors, 12 charts, 5 drop-downs | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/05-Excel-Data-Analytics-Module/04-All-In-One-Workbook-and-Submission) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/05-Excel-Data-Analytics-Module/04-All-In-One-Workbook-and-Submission/index.html) |

[← By Sector / Industry](../README.md) · [← Lens dashboard](../../README.md)