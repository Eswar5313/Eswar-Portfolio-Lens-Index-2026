# By Sector / Industry

Industry context of the problem. 19 values across 83 projects.

| Sector / Industry | Projects | Folder |
|---|:-:|---|
| [Automotive & Electric Vehicles](Automotive-Electric-Vehicles/) | 12 | [`Automotive-Electric-Vehicles/`](Automotive-Electric-Vehicles/) |
| [Career & Personal Branding](Career-Personal-Branding/) | 13 | [`Career-Personal-Branding/`](Career-Personal-Branding/) |
| [Cloud & DevOps](Cloud-DevOps/) | 1 | [`Cloud-DevOps/`](Cloud-DevOps/) |
| [Construction & Infrastructure](Construction-Infrastructure/) | 3 | [`Construction-Infrastructure/`](Construction-Infrastructure/) |
| [Cross-industry](Cross-industry/) | 3 | [`Cross-industry/`](Cross-industry/) |
| [Cyber Security](Cyber-Security/) | 20 | [`Cyber-Security/`](Cyber-Security/) |
| [E-commerce & Quick-commerce](E-commerce-Quick-commerce/) | 10 | [`E-commerce-Quick-commerce/`](E-commerce-Quick-commerce/) |
| [Education & EdTech](Education-EdTech/) | 5 | [`Education-EdTech/`](Education-EdTech/) |
| [Fintech & Financial Services](Fintech-Financial-Services/) | 8 | [`Fintech-Financial-Services/`](Fintech-Financial-Services/) |
| [Food & Hospitality](Food-Hospitality/) | 3 | [`Food-Hospitality/`](Food-Hospitality/) |
| [HR & Corporate Services](HR-Corporate-Services/) | 3 | [`HR-Corporate-Services/`](HR-Corporate-Services/) |
| [Health, Fitness & Wellbeing](Health-Fitness-Wellbeing/) | 5 | [`Health-Fitness-Wellbeing/`](Health-Fitness-Wellbeing/) |
| [IT, SaaS & AI Products](IT-SaaS-AI-Products/) | 9 | [`IT-SaaS-AI-Products/`](IT-SaaS-AI-Products/) |
| [Logistics & Supply Chain](Logistics-Supply-Chain/) | 2 | [`Logistics-Supply-Chain/`](Logistics-Supply-Chain/) |
| [Manufacturing, Energy & Utilities](Manufacturing-Energy-Utilities/) | 6 | [`Manufacturing-Energy-Utilities/`](Manufacturing-Energy-Utilities/) |
| [Media, Gaming & Entertainment](Media-Gaming-Entertainment/) | 3 | [`Media-Gaming-Entertainment/`](Media-Gaming-Entertainment/) |
| [Mobility & Ride-hailing](Mobility-Ride-hailing/) | 3 | [`Mobility-Ride-hailing/`](Mobility-Ride-hailing/) |
| [Real Estate](Real-Estate/) | 2 | [`Real-Estate/`](Real-Estate/) |
| [Retail & Consumer Brands](Retail-Consumer-Brands/) | 3 | [`Retail-Consumer-Brands/`](Retail-Consumer-Brands/) |

[← Lens dashboard](../README.md)