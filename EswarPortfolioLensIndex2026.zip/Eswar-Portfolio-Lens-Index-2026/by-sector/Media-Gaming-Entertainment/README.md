# Sector / Industry: Media, Gaming & Entertainment

3 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Amazon Prime Video Catalogue EDA** | HEXA Solutions | Content-catalogue analysis — genres, release years, ratings, countries and runtime distributions. | Catalogue mix and growth view | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/05-Amazon-Prime-Catalogue-EDA) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/05-Amazon-Prime-Catalogue-EDA/index.html) |
| **Video Game Sales Analysis** | HEXA Solutions | Global/regional sales by platform, genre and publisher with trend and market-share views. | Platform and genre leaders by region | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/06-Video-Game-Sales) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/06-Video-Game-Sales/index.html) |
| **Tennis SportRadar API Pipeline** | HEXA Solutions | API ingestion → SQLite → Streamlit app for competitions, rankings and venues. | Working API-to-app pipeline (Streamlit) | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/12-Tennis-SportRadar-API-Pipeline) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/12-Tennis-SportRadar-API-Pipeline/index.html) |

[← By Sector / Industry](../README.md) · [← Lens dashboard](../../README.md)