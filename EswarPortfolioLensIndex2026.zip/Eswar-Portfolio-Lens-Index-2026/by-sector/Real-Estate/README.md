# Sector / Industry: Real Estate

2 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Airbnb Listings Dashboard** | HEXA Solutions | Listing prices, availability, room types and neighbourhood analysis presented as a dashboard. | Price and availability heat-map by neighbourhood | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/09-Airbnb-Dashboard) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/09-Airbnb-Dashboard/index.html) |
| **Dubai House Price Model** | HEXA Solutions | Regression model of Dubai property prices by area, size, type and amenities. | Price-per-sqft baseline ≈ 99 AED (verified) | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/13-Dubai-House-Price-Model) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/13-Dubai-House-Price-Model/index.html) |

[← By Sector / Industry](../README.md) · [← Lens dashboard](../../README.md)