# Sector / Industry: Retail & Consumer Brands

3 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Video Game Sales Analysis** | HEXA Solutions | Global/regional sales by platform, genre and publisher with trend and market-share views. | Platform and genre leaders by region | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/06-Video-Game-Sales) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/06-Video-Game-Sales/index.html) |
| **Excel — Multi-Region Sales Dashboard** | Internship Studio | 645-row declared-synthetic sales dataset with regional/rep dashboard, 12,621 formulas. | ₹14.26 Cr revenue = 101% of target; West best, South under target | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/10-Multi-Region-Sales-Dashboard-Excel) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/10-Multi-Region-Sales-Dashboard-Excel/index.html) |
| **Digital Marketing — EcoStyle Facebook Ads Campaign** | Internship Studio | Campaign workbook, 5 ad creatives and 12-page report for a fashion brand. | Base case 181 purchases, ₹2.72 L revenue, ROAS 4.53×, CPA ₹331, +23.5% sales | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/16-EcoStyle-Facebook-Ads-Campaign-Plan) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/16-EcoStyle-Facebook-Ads-Campaign-Plan/index.html) |

[← By Sector / Industry](../README.md) · [← Lens dashboard](../../README.md)