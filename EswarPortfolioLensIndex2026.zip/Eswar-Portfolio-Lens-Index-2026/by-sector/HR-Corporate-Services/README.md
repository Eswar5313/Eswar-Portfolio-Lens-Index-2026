# Sector / Industry: HR & Corporate Services

3 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Mental Health in Tech Survey Analysis** | HEXA Solutions | EDA of the OSMI tech-workplace survey — treatment-seeking, employer support and workplace attitudes by company size and geography. | Segmented view of support gaps by company size | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/02-Mental-Health-in-Tech) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/02-Mental-Health-in-Tech/index.html) |
| **HR — Policy Framework, Onboarding & Engagement** | Internship Studio | 18-page ABC Co. policy manual (induction, 90-day onboarding, discipline ladder, POSH/maternity, engagement proposal) + budget workbook. | Engagement budget ₹4,00,000 = ₹5,714/employee (0.95% of payroll) | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/11-HR-Policy-Framework-Onboarding-Engagement) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/11-HR-Policy-Framework-Onboarding-Engagement/index.html) |
| **Corporate Psychology — TechX Thrive Wellbeing Program** | Internship Studio | Proposal, evaluation plan and reflective report: 5 pillars, 27 interventions, 20 KPIs, pilot-vs-comparison DiD design. | Year-1 budget ₹1.21 Cr = ₹23,341/employee | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/14-Employee-Wellbeing-Program-TechX) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/14-Employee-Wellbeing-Program-TechX/index.html) |

[← By Sector / Industry](../README.md) · [← Lens dashboard](../../README.md)