# Sector / Industry: Logistics & Supply Chain

2 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **FedEx Logistics EDA** | HEXA Solutions | Exploratory analysis of shipment data — delivery timelines, route/mode mix, delay drivers and cost patterns, framed from a supply-chain operator's lens. | Delay-driver breakdown by mode and lane | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/01-FedEx-Logistics-EDA) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/01-FedEx-Logistics-EDA/index.html) |
| **The 2,000 SKU Problem — Blog** | Personal Builds | Quick-commerce dark-store assortment: capacity framing, ABC×XYZ + basket-role segmentation, replenishment clock, availability measurement. | 4 essays + hub | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/06-Personal-Builds-and-Sites/08-The-2000-SKU-Problem-Blog) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/06-Personal-Builds-and-Sites/08-The-2000-SKU-Problem-Blog/index.html) |

[← By Sector / Industry](../README.md) · [← Lens dashboard](../../README.md)