# Tools & Technologies: Jest

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **EV 02 — Charging Station Locator App** | Codec Technologies | Expo / React Native app with map search and station details. | Jest test suite | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/04-Codec-Technologies-EV-and-Cyber/EV-02-Charging-Station-Locator-App) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/04-Codec-Technologies-EV-and-Cyber/EV-02-Charging-Station-Locator-App/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)