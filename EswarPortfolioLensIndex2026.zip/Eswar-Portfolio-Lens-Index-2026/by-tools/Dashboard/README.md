# Tools & Technologies: Dashboard

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **EV 06 — IoT EV Health Dashboard** | Codec Technologies | Telemetry ingestion and health dashboard with compile-checked ESP8266 firmware. | Firmware compile-checked (not run on hardware) | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/04-Codec-Technologies-EV-and-Cyber/EV-06-IoT-EV-Health-Dashboard) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/04-Codec-Technologies-EV-and-Cyber/EV-06-IoT-EV-Health-Dashboard/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)