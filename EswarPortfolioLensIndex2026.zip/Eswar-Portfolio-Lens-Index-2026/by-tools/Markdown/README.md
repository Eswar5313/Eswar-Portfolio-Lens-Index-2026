# Tools & Technologies: Markdown

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Career Control Tower — GitHub Profile Dashboard** | Personal Builds | Multi-page profile (README + Education/Experience/Certifications/Projects/Simulations/Publications) with capsule headers, badges, mermaid timelines; navy/gold and Hindustani themes. | 7 pages, KPI badges, fitment snapshots | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/06-Personal-Builds-and-Sites/01-Career-Control-Tower-GitHub-Profile) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/06-Personal-Builds-and-Sites/01-Career-Control-Tower-GitHub-Profile/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)