# Tools & Technologies: matplotlib

2 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **FedEx Logistics EDA** | HEXA Solutions | Exploratory analysis of shipment data — delivery timelines, route/mode mix, delay drivers and cost patterns, framed from a supply-chain operator's lens. | Delay-driver breakdown by mode and lane | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/01-FedEx-Logistics-EDA) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/01-FedEx-Logistics-EDA/index.html) |
| **Amazon Prime Video Catalogue EDA** | HEXA Solutions | Content-catalogue analysis — genres, release years, ratings, countries and runtime distributions. | Catalogue mix and growth view | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/05-Amazon-Prime-Catalogue-EDA) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/05-Amazon-Prime-Catalogue-EDA/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)