# Tools & Technologies: DSA

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Smart Library Management System (C++ & DSA)** | Internship Studio | Linked-list catalogue, stack-based undo, queue reservations, sorting, books.txt loader. | Compiles clean with -Wall -Wextra; valgrind 0 leaks | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/04-Smart-Library-Management-CPP) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/04-Smart-Library-Management-CPP/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)