# Tools & Technologies: Tesseract.js

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Master Financial Ledger** | Personal Builds | Household budget tracker: vegetarian catalogue, bill scanning (AI + Tesseract.js OCR fallback), shopping directory, dashboard, history import. | Diagnosed localStorage quota issue from base64 images | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/06-Personal-Builds-and-Sites/05-Master-Financial-Ledger) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/06-Personal-Builds-and-Sites/05-Master-Financial-Ledger/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)