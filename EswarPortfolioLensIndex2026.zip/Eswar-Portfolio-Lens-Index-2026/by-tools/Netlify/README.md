# Tools & Technologies: Netlify

2 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Portfolio Websites (5 themes)** | Personal Builds | Classic navy/gold executive, 2050 Mission Control, superhero HUD, boarding-pass manifest, Dark Knight noir and Hindustani tricolour — all single-file Netlify sites; plus a cinematic Next.js (GSAP + Three.js) build on Vercel. | Filterable project showcases, animated KPI bands | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/06-Personal-Builds-and-Sites/02-Portfolio-Websites) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/06-Personal-Builds-and-Sites/02-Portfolio-Websites/index.html) |
| **Career Tool Suite (Netlify)** | Personal Builds | Auto-Apply Command Center, Career Assurance Engine, E-Commerce Universe directory, Tools Arsenal, Credential Vault. | 5 deployed single-file tools | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/06-Personal-Builds-and-Sites/04-Career-Tool-Suite) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/06-Personal-Builds-and-Sites/04-Career-Tool-Suite/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)