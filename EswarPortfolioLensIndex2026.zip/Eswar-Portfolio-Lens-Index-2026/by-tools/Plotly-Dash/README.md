# Tools & Technologies: Plotly Dash

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **EV 10 — EV Market Forecast Dashboard** | Codec Technologies | Real IEA Global EV Outlook data via API, 20 sourced policies, logistic/Bass/CAGR forecasts to 2035, Plotly Dash app + static HTML. | 40 tests; forecasts to 2035 | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/04-Codec-Technologies-EV-and-Cyber/EV-10-EV-Market-Forecast-Dashboard) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/04-Codec-Technologies-EV-and-Cyber/EV-10-EV-Market-Forecast-Dashboard/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)