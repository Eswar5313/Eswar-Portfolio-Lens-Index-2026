# Tools & Technologies: SQLite

2 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **SQL — NSE Stock Market Analysis** | HEXA Solutions | SQLite database of NSE equities with SQL queries for returns, volatility, moving averages and sector comparisons. | Reusable SQL query bank + SQLite DB | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/07-SQL-NSE-Stock-Market) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/07-SQL-NSE-Stock-Market/index.html) |
| **Tennis SportRadar API Pipeline** | HEXA Solutions | API ingestion → SQLite → Streamlit app for competitions, rankings and venues. | Working API-to-app pipeline (Streamlit) | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/12-Tennis-SportRadar-API-Pipeline) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/12-Tennis-SportRadar-API-Pipeline/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)