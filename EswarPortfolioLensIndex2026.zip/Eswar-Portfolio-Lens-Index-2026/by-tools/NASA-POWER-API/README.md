# Tools & Technologies: NASA POWER API

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **EV 03 — Solar EV Charging Station Design** | Codec Technologies | Sizing and yield model using real NASA POWER irradiance data. | Real NASA POWER data pipeline | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/04-Codec-Technologies-EV-and-Cyber/EV-03-Solar-EV-Charging-Station) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/04-Codec-Technologies-EV-and-Cyber/EV-03-Solar-EV-Charging-Station/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)