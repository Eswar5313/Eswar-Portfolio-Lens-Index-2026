# Tools & Technologies: Playwright

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **CartShare — Collaborative Shopping Cart Web App** | Internship Studio | Static HTML/CSS/JS collaborative cart, deployed on GitHub Pages; Playwright-tested. | 54/54 Playwright checks passing | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/07-CartShare-Collaborative-Cart) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/07-CartShare-Collaborative-Cart/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)