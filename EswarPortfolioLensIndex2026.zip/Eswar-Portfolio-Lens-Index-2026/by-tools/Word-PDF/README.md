# Tools & Technologies: Word/PDF

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **HR — Policy Framework, Onboarding & Engagement** | Internship Studio | 18-page ABC Co. policy manual (induction, 90-day onboarding, discipline ladder, POSH/maternity, engagement proposal) + budget workbook. | Engagement budget ₹4,00,000 = ₹5,714/employee (0.95% of payroll) | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/11-HR-Policy-Framework-Onboarding-Engagement) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/11-HR-Policy-Framework-Onboarding-Engagement/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)