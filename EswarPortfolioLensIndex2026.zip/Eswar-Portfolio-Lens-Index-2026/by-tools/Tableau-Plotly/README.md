# Tools & Technologies: Tableau / Plotly

2 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **India EV Market Dashboard** | HEXA Solutions | EV registrations/sales by state, segment and maker with a dashboard view of adoption trends. | State-wise adoption dashboard | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/08-India-EV-Dashboard) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/08-India-EV-Dashboard/index.html) |
| **Airbnb Listings Dashboard** | HEXA Solutions | Listing prices, availability, room types and neighbourhood analysis presented as a dashboard. | Price and availability heat-map by neighbourhood | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/09-Airbnb-Dashboard) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/09-Airbnb-Dashboard/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)