# Tools & Technologies: S3

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **AWS — EC2 + S3 Node.js app & ROS Noetic deployment** | Internship Studio | Express gallery app (declared substitute), 11 CLI/bootstrap scripts, EC2/S3 + ROS runbooks; screenshots to be captured by me. | 7/7 local tests; t2.micro needs 2 GB swap (documented) | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/13-AWS-EC2-S3-NodeJS-ROS-Deployment) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/13-AWS-EC2-S3-NodeJS-ROS-Deployment/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)