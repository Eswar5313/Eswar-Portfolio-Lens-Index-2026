# Tools & Technologies: SVG

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Adobe Illustrator — Vector Design Portfolio** | Internship Studio | 34 original SVGs: icon set, tee graphic, poster series, patterns, mascot family, café social kit, 3D lettering; 10-page portfolio PDF. | 34 originals, no stock or copied art | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/15-Illustrator-Vector-Design-Portfolio) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/15-Illustrator-Vector-Design-Portfolio/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)