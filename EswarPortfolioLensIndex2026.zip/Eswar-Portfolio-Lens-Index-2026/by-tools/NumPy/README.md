# Tools & Technologies: NumPy

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **EV 01 — Battery Management System Simulation** | Codec Technologies | 96s2p pack model with EKF state-of-charge estimation, SOH tracking and thermal manager. | EKF SOC RMSE 0.63%; SOH 90.1% after 500 cycles; 23 tests | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/04-Codec-Technologies-EV-and-Cyber/EV-01-BMS-Simulation) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/04-Codec-Technologies-EV-and-Cyber/EV-01-BMS-Simulation/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)