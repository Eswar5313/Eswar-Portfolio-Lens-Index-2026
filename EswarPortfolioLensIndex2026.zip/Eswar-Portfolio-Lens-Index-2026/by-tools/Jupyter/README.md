# Tools & Technologies: Jupyter

3 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Project Panopticon — AI Exam Proctoring** | Internship Studio | Merge system events with video telemetry (merge_asof, ffill), 10-s rolling windows, balanced RandomForest, 0.90 precision threshold with PR curve. | Precision 1.00 / recall 0.48 at 0.90 threshold → GO | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/01-Exam-Proctoring-AI-Panopticon) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/01-Exam-Proctoring-AI-Panopticon/index.html) |
| **Project Overheat — Predictive Maintenance** | Internship Studio | 12-h rolling sensor features, 24-h target shift, chronological split, balanced RF with feature importance. | 3/3 test failures warned 23–24 h ahead at threshold 0.20 | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/02-Predictive-Maintenance-IoT-ML) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/02-Predictive-Maintenance-IoT-ML/index.html) |
| **ML — Student Performance Regression** | Internship Studio | Ridge regression on the real StudentsPerformance dataset, report + notebook + standalone script (dataset not redistributed). | R² 0.8805, MAE 4.21 | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/12-Student-Performance-ML-Regression) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/12-Student-Performance-ML-Regression/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)