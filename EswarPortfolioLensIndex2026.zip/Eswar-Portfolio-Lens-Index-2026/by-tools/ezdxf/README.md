# Tools & Technologies: ezdxf

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **AutoCAD — Civil / Electrical / Mechanical Drawings** | Internship Studio | Single-storey plan, amplitude-limiter schematic + wiring schedule, screw-jack 7-part sheet + assembly/BOM authored as DXF. | 1,230 entities, DXF audit 0 errors | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/08-AutoCAD-Civil-Electrical-Mechanical) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/08-AutoCAD-Civil-Electrical-Mechanical/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)