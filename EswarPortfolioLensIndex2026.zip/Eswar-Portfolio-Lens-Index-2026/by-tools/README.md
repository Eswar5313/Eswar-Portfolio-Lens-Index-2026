# By Tools & Technologies

Software, libraries and platforms used. 54 values across 83 projects.

| Tools & Technologies | Projects | Folder |
|---|:-:|---|
| [AWS EC2](AWS-EC2/) | 1 | [`AWS-EC2/`](AWS-EC2/) |
| [Arduino](Arduino/) | 1 | [`Arduino/`](Arduino/) |
| [AutoCAD](AutoCAD/) | 1 | [`AutoCAD/`](AutoCAD/) |
| [C++](C/) | 1 | [`C/`](C/) |
| [CSS](CSS/) | 6 | [`CSS/`](CSS/) |
| [Chart.js](Chart-js/) | 1 | [`Chart-js/`](Chart-js/) |
| [DSA](DSA/) | 1 | [`DSA/`](DSA/) |
| [DXF](DXF/) | 1 | [`DXF/`](DXF/) |
| [Dashboard](Dashboard/) | 1 | [`Dashboard/`](Dashboard/) |
| [Design](Design/) | 1 | [`Design/`](Design/) |
| [ESP8266](ESP8266/) | 1 | [`ESP8266/`](ESP8266/) |
| [Excel](Excel/) | 20 | [`Excel/`](Excel/) |
| [Expo](Expo/) | 1 | [`Expo/`](Expo/) |
| [Figma/FigJam](Figma-FigJam/) | 1 | [`Figma-FigJam/`](Figma-FigJam/) |
| [Gamma](Gamma/) | 1 | [`Gamma/`](Gamma/) |
| [GitHub](GitHub/) | 1 | [`GitHub/`](GitHub/) |
| [HTML](HTML/) | 13 | [`HTML/`](HTML/) |
| [IEA API](IEA-API/) | 1 | [`IEA-API/`](IEA-API/) |
| [Illustrator](Illustrator/) | 1 | [`Illustrator/`](Illustrator/) |
| [JS](JS/) | 4 | [`JS/`](JS/) |
| [JavaScript](JavaScript/) | 1 | [`JavaScript/`](JavaScript/) |
| [Jest](Jest/) | 1 | [`Jest/`](Jest/) |
| [Jupyter](Jupyter/) | 3 | [`Jupyter/`](Jupyter/) |
| [Loom](Loom/) | 1 | [`Loom/`](Loom/) |
| [Markdown](Markdown/) | 1 | [`Markdown/`](Markdown/) |
| [Mermaid](Mermaid/) | 1 | [`Mermaid/`](Mermaid/) |
| [NASA POWER API](NASA-POWER-API/) | 1 | [`NASA-POWER-API/`](NASA-POWER-API/) |
| [Netlify](Netlify/) | 2 | [`Netlify/`](Netlify/) |
| [Next.js](Next-js/) | 1 | [`Next-js/`](Next-js/) |
| [Node.js](Node-js/) | 1 | [`Node-js/`](Node-js/) |
| [NumPy](NumPy/) | 1 | [`NumPy/`](NumPy/) |
| [PDF](PDF/) | 20 | [`PDF/`](PDF/) |
| [PPTX](PPTX/) | 7 | [`PPTX/`](PPTX/) |
| [Playwright](Playwright/) | 1 | [`Playwright/`](Playwright/) |
| [Plotly Dash](Plotly-Dash/) | 1 | [`Plotly-Dash/`](Plotly-Dash/) |
| [Python](Python/) | 47 | [`Python/`](Python/) |
| [REST API](REST-API/) | 1 | [`REST-API/`](REST-API/) |
| [ROS](ROS/) | 1 | [`ROS/`](ROS/) |
| [React Native](React-Native/) | 1 | [`React-Native/`](React-Native/) |
| [S3](S3/) | 1 | [`S3/`](S3/) |
| [SQL](SQL/) | 2 | [`SQL/`](SQL/) |
| [SQLite](SQLite/) | 2 | [`SQLite/`](SQLite/) |
| [SVG](SVG/) | 1 | [`SVG/`](SVG/) |
| [Streamlit](Streamlit/) | 1 | [`Streamlit/`](Streamlit/) |
| [Tableau / Plotly](Tableau-Plotly/) | 2 | [`Tableau-Plotly/`](Tableau-Plotly/) |
| [Tesseract.js](Tesseract-js/) | 1 | [`Tesseract-js/`](Tesseract-js/) |
| [Vercel](Vercel/) | 1 | [`Vercel/`](Vercel/) |
| [Word/PDF](Word-PDF/) | 1 | [`Word-PDF/`](Word-PDF/) |
| [ezdxf](ezdxf/) | 1 | [`ezdxf/`](ezdxf/) |
| [matplotlib](matplotlib/) | 2 | [`matplotlib/`](matplotlib/) |
| [pandas](pandas/) | 10 | [`pandas/`](pandas/) |
| [scikit-learn](scikit-learn/) | 7 | [`scikit-learn/`](scikit-learn/) |
| [scipy](scipy/) | 1 | [`scipy/`](scipy/) |
| [seaborn](seaborn/) | 5 | [`seaborn/`](seaborn/) |

[← Lens dashboard](../README.md)