# Tools & Technologies: Gamma

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Nykaa App — UX Exploration & Decision Model** | Product Management | Goal-driven app exploration, friction log, Severity×Frequency matrix, RICE scoring, 50-session study design, plus a 50-product ValueIndex decision model (declared-synthetic). | Master Edition PDF with embedded 380-formula workbook | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/02-Product-Management-Case-Studies/01-Nykaa-UX-Exploration) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/02-Product-Management-Case-Studies/01-Nykaa-UX-Exploration/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)