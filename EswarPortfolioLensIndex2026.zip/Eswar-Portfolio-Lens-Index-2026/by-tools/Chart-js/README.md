# Tools & Technologies: Chart.js

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Flipkart Customer Satisfaction (CSAT)** | HEXA Solutions | Customer-support CSAT analysis across channels, agents, shifts and issue categories with an interactive Chart.js dashboard. | CSAT gradient 4.48 → 3.66 across the studied dimension (verified) | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/03-Flipkart-CSAT-Analysis) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/03-Flipkart-CSAT-Analysis/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)