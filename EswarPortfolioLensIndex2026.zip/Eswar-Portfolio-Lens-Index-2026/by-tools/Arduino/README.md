# Tools & Technologies: Arduino

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **EV 08 — Smart Traffic Light with EV Priority** | Codec Technologies | Signal controller simulation plus Arduino firmware for EV priority. | Arduino firmware compile-checked | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/04-Codec-Technologies-EV-and-Cyber/EV-08-Smart-Traffic-Light-EV-Priority) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/04-Codec-Technologies-EV-and-Cyber/EV-08-Smart-Traffic-Light-EV-Priority/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)