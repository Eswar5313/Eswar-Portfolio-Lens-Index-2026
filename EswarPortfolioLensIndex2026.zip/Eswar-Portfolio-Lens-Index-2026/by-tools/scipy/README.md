# Tools & Technologies: scipy

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Strava / Fitbit Fitness Analytics** | HEXA Solutions | Activity, sleep and sedentary-time analysis from wearable exports with correlation study. | Sedentary-time × sleep correlation r = −0.60 (verified) | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/10-Strava-Fitbit-Fitness-Analytics) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/10-Strava-Fitbit-Fitness-Analytics/index.html) |

[← By Tools & Technologies](../README.md) · [← Lens dashboard](../../README.md)