# Deliverable Type: Drawings / vector artwork

3 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **AutoCAD — Civil / Electrical / Mechanical Drawings** | Internship Studio | Single-storey plan, amplitude-limiter schematic + wiring schedule, screw-jack 7-part sheet + assembly/BOM authored as DXF. | 1,230 entities, DXF audit 0 errors | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/08-AutoCAD-Civil-Electrical-Mechanical) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/08-AutoCAD-Civil-Electrical-Mechanical/index.html) |
| **Adobe Illustrator — Vector Design Portfolio** | Internship Studio | 34 original SVGs: icon set, tee graphic, poster series, patterns, mascot family, café social kit, 3D lettering; 10-page portfolio PDF. | 34 originals, no stock or copied art | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/15-Illustrator-Vector-Design-Portfolio) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/15-Illustrator-Vector-Design-Portfolio/index.html) |
| **Digital Marketing — EcoStyle Facebook Ads Campaign** | Internship Studio | Campaign workbook, 5 ad creatives and 12-page report for a fashion brand. | Base case 181 purchases, ₹2.72 L revenue, ROAS 4.53×, CPA ₹331, +23.5% sales | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/16-EcoStyle-Facebook-Ads-Campaign-Plan) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/16-EcoStyle-Facebook-Ads-Campaign-Plan/index.html) |

[← By Deliverable Type](../README.md) · [← Lens dashboard](../../README.md)