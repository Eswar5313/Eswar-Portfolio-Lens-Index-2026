# Deliverable Type: Video / Loom

2 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Nykaa App — UX Exploration & Decision Model** | Product Management | Goal-driven app exploration, friction log, Severity×Frequency matrix, RICE scoring, 50-session study design, plus a 50-product ValueIndex decision model (declared-synthetic). | Master Edition PDF with embedded 380-formula workbook | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/02-Product-Management-Case-Studies/01-Nykaa-UX-Exploration) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/02-Product-Management-Case-Studies/01-Nykaa-UX-Exploration/index.html) |
| **Project Panopticon — AI Exam Proctoring** | Internship Studio | Merge system events with video telemetry (merge_asof, ffill), 10-s rolling windows, balanced RandomForest, 0.90 precision threshold with PR curve. | Precision 1.00 / recall 0.48 at 0.90 threshold → GO | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/01-Exam-Proctoring-AI-Panopticon) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/01-Exam-Proctoring-AI-Panopticon/index.html) |

[← By Deliverable Type](../README.md) · [← Lens dashboard](../../README.md)