# By Deliverable Type

What was actually produced. 9 values across 83 projects.

| Deliverable Type | Projects | Folder |
|---|:-:|---|
| [Code / notebook](Code-notebook/) | 46 | [`Code-notebook/`](Code-notebook/) |
| [Dataset](Dataset/) | 10 | [`Dataset/`](Dataset/) |
| [Drawings / vector artwork](Drawings-vector-artwork/) | 3 | [`Drawings-vector-artwork/`](Drawings-vector-artwork/) |
| [Excel workbook (live formulas)](Excel-workbook-live-formulas/) | 20 | [`Excel-workbook-live-formulas/`](Excel-workbook-live-formulas/) |
| [Interactive dashboard](Interactive-dashboard/) | 20 | [`Interactive-dashboard/`](Interactive-dashboard/) |
| [PDF report](PDF-report/) | 44 | [`PDF-report/`](PDF-report/) |
| [Presentation deck](Presentation-deck/) | 21 | [`Presentation-deck/`](Presentation-deck/) |
| [Video / Loom](Video-Loom/) | 2 | [`Video-Loom/`](Video-Loom/) |
| [Web app / site](Web-app-site/) | 7 | [`Web-app-site/`](Web-app-site/) |

[← Lens dashboard](../README.md)