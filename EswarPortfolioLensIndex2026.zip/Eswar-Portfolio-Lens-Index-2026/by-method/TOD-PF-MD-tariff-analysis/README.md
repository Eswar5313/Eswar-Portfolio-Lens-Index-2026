# Methods & Frameworks: TOD / PF / MD tariff analysis

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Textile Mill — HT Electricity Bill Energy Audit** | Internship Studio | Bill reconstruction, TOD/PF/MD analysis and savings measures (APFC, demand controller, TOD shift, IE3+VFD, LED). | Annual bill ₹10.76 Cr @ ₹10.26/kWh; savings ₹81.9 L = 7.6% | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/05-Textile-Electricity-Bill-Energy-Audit) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/05-Textile-Electricity-Bill-Energy-Audit/index.html) |

[← By Methods & Frameworks](../README.md) · [← Lens dashboard](../../README.md)