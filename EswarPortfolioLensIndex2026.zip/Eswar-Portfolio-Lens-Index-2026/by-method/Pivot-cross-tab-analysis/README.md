# Methods & Frameworks: Pivot / cross-tab analysis

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Assignment 3 — Advanced Analysis** | Data Analytics Module 1 | VLOOKUP/HLOOKUP/INDEX-MATCH, 5 pivot cross-tabs, 6 charts, forecasting/trend, interactive dashboard with 3 drop-downs. | 1,497 formulas, 0 errors; dashboard tested on 3 filter combinations | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/05-Excel-Data-Analytics-Module/03-Advanced-Analysis-Lookups-Pivots-Dashboard) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/05-Excel-Data-Analytics-Module/03-Advanced-Analysis-Lookups-Pivots-Dashboard/index.html) |

[← By Methods & Frameworks](../README.md) · [← Lens dashboard](../../README.md)