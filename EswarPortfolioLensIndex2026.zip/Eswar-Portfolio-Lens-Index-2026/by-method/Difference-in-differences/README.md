# Methods & Frameworks: Difference-in-differences

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Corporate Psychology — TechX Thrive Wellbeing Program** | Internship Studio | Proposal, evaluation plan and reflective report: 5 pillars, 27 interventions, 20 KPIs, pilot-vs-comparison DiD design. | Year-1 budget ₹1.21 Cr = ₹23,341/employee | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/14-Employee-Wellbeing-Program-TechX) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/14-Employee-Wellbeing-Program-TechX/index.html) |

[← By Methods & Frameworks](../README.md) · [← Lens dashboard](../../README.md)