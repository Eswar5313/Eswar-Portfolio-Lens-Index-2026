# Methods & Frameworks: Holdout / A-B experiment design

2 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **VitaFit — PRD for Engagement & Retention Features** | Product Management | PRD for Squads & Streak Challenges and Instructor Circles & Coach Notes; 6 flowcharts, 18 wireframes, event schema; research annex with 12 sources and FigJam boards. | 50-page master; 13-sheet / 1,503-formula workbook, 0 errors | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/02-Product-Management-Case-Studies/05-VitaFit-PRD-and-Core-Flows) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/02-Product-Management-Case-Studies/05-VitaFit-PRD-and-Core-Flows/index.html) |
| **Corporate Psychology — TechX Thrive Wellbeing Program** | Internship Studio | Proposal, evaluation plan and reflective report: 5 pillars, 27 interventions, 20 KPIs, pilot-vs-comparison DiD design. | Year-1 budget ₹1.21 Cr = ₹23,341/employee | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/14-Employee-Wellbeing-Program-TechX) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/14-Employee-Wellbeing-Program-TechX/index.html) |

[← By Methods & Frameworks](../README.md) · [← Lens dashboard](../../README.md)