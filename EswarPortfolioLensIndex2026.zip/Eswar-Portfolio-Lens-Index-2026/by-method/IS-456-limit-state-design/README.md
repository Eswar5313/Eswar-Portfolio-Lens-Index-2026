# Methods & Frameworks: IS 456 limit-state design

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **RCC Structural Design (IS 456)** | Internship Studio | One-way slab 10×4 m (M25/Fe415), doubly-reinforced hall slab + beam (M20/Fe415), biaxial column 3 m. | Slab D170 10@120; beam 400×750 8-32 + 8-25; column 300×450 8-16, interaction 0.389 | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/06-RCC-Structural-Design-IS456) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/06-RCC-Structural-Design-IS456/index.html) |

[← By Methods & Frameworks](../README.md) · [← Lens dashboard](../../README.md)