# Methods & Frameworks: Porter's Five Forces

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Uber — Proactive Pickup Guidance** | Product Management | Should Uber guide riders to better pickup points in dense areas? Market research + competitive analysis, Five Forces, TAM/SAM/SOM, interview toolkit and 8-sheet workbook with pivots. | 14-page master, 11-slide zero-white-space deck | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/02-Product-Management-Case-Studies/03-Uber-Pickup-Coordination) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/02-Product-Management-Case-Studies/03-Uber-Pickup-Coordination/index.html) |

[← By Methods & Frameworks](../README.md) · [← Lens dashboard](../../README.md)