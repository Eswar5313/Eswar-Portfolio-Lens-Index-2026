# Methods & Frameworks: k-anonymity

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Cyber 14 — Credential-Leak / Threat-Intel Monitor** | Codec Technologies | k-anonymity credential-leak checks and threat-intel monitoring on lawful/synthetic sources (declared substitute for dark-web brief). | k-anonymity lookup; synthetic sources | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/04-Codec-Technologies-EV-and-Cyber/CYBER-14-Credential-Leak-Threat-Intel-Monitor) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/04-Codec-Technologies-EV-and-Cyber/CYBER-14-Credential-Leak-Threat-Intel-Monitor/index.html) |

[← By Methods & Frameworks](../README.md) · [← Lens dashboard](../../README.md)