# Methods & Frameworks: JTBD / Five Whys / Double Diamond

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Zepto — Growing Basket Size / AOV** | Product Management | Group case: segmentation, blockers & problem framing (JTBD, Five Whys), 2–3 solutions and RICE prioritisation backed by Excel calculations. | Segment cards + RICE ranking with workbook support | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/02-Product-Management-Case-Studies/04-Zepto-AOV-Basket-Size) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/02-Product-Management-Case-Studies/04-Zepto-AOV-Basket-Size/index.html) |

[← By Methods & Frameworks](../README.md) · [← Lens dashboard](../../README.md)