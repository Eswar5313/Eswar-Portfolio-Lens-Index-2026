# Methods & Frameworks: Life-cycle assessment

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **EV 07 — EV Lifecycle (LCA) Analysis** | Codec Technologies | Cradle-to-grave emissions comparison using cited ICCT / CEA factors. | Sourced emission factors, scenario tables | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/04-Codec-Technologies-EV-and-Cyber/EV-07-EV-Lifecycle-Analysis) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/04-Codec-Technologies-EV-and-Cyber/EV-07-EV-Lifecycle-Analysis/index.html) |

[← By Methods & Frameworks](../README.md) · [← Lens dashboard](../../README.md)