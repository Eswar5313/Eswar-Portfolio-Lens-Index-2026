# By Methods & Frameworks

Analytical / product / engineering methods applied. 27 values across 83 projects.

| Methods & Frameworks | Projects | Folder |
|---|:-:|---|
| [APFD test prioritisation](APFD-test-prioritisation/) | 1 | [`APFD-test-prioritisation/`](APFD-test-prioritisation/) |
| [Classification (RandomForest etc.)](Classification-RandomForest-etc/) | 4 | [`Classification-RandomForest-etc/`](Classification-RandomForest-etc/) |
| [Correlation analysis](Correlation-analysis/) | 1 | [`Correlation-analysis/`](Correlation-analysis/) |
| [Difference-in-differences](Difference-in-differences/) | 1 | [`Difference-in-differences/`](Difference-in-differences/) |
| [Exploratory data analysis](Exploratory-data-analysis/) | 7 | [`Exploratory-data-analysis/`](Exploratory-data-analysis/) |
| [Extended Kalman Filter](Extended-Kalman-Filter/) | 1 | [`Extended-Kalman-Filter/`](Extended-Kalman-Filter/) |
| [Forecasting (moving average, logistic, Bass)](Forecasting-moving-average-logistic-Bass/) | 1 | [`Forecasting-moving-average-logistic-Bass/`](Forecasting-moving-average-logistic-Bass/) |
| [Holdout / A-B experiment design](Holdout-A-B-experiment-design/) | 2 | [`Holdout-A-B-experiment-design/`](Holdout-A-B-experiment-design/) |
| [IS 456 limit-state design](IS-456-limit-state-design/) | 1 | [`IS-456-limit-state-design/`](IS-456-limit-state-design/) |
| [JTBD / Five Whys / Double Diamond](JTBD-Five-Whys-Double-Diamond/) | 1 | [`JTBD-Five-Whys-Double-Diamond/`](JTBD-Five-Whys-Double-Diamond/) |
| [Life-cycle assessment](Life-cycle-assessment/) | 1 | [`Life-cycle-assessment/`](Life-cycle-assessment/) |
| [Lookup modelling (VLOOKUP/INDEX-MATCH)](Lookup-modelling-VLOOKUP-INDEX-MATCH/) | 2 | [`Lookup-modelling-VLOOKUP-INDEX-MATCH/`](Lookup-modelling-VLOOKUP-INDEX-MATCH/) |
| [Pivot / cross-tab analysis](Pivot-cross-tab-analysis/) | 1 | [`Pivot-cross-tab-analysis/`](Pivot-cross-tab-analysis/) |
| [Porter's Five Forces](Porter-s-Five-Forces/) | 1 | [`Porter-s-Five-Forces/`](Porter-s-Five-Forces/) |
| [RICE prioritisation](RICE-prioritisation/) | 2 | [`RICE-prioritisation/`](RICE-prioritisation/) |
| [ROAS / CPA campaign modelling](ROAS-CPA-campaign-modelling/) | 1 | [`ROAS-CPA-campaign-modelling/`](ROAS-CPA-campaign-modelling/) |
| [Ratio analysis & articulated statements](Ratio-analysis-articulated-statements/) | 1 | [`Ratio-analysis-articulated-statements/`](Ratio-analysis-articulated-statements/) |
| [Regression modelling](Regression-modelling/) | 4 | [`Regression-modelling/`](Regression-modelling/) |
| [Rolling-window feature engineering](Rolling-window-feature-engineering/) | 2 | [`Rolling-window-feature-engineering/`](Rolling-window-feature-engineering/) |
| [STP segmentation](STP-segmentation/) | 5 | [`STP-segmentation/`](STP-segmentation/) |
| [Sensitivity analysis](Sensitivity-analysis/) | 1 | [`Sensitivity-analysis/`](Sensitivity-analysis/) |
| [Set-cover suite reduction](Set-cover-suite-reduction/) | 1 | [`Set-cover-suite-reduction/`](Set-cover-suite-reduction/) |
| [Severity × Frequency matrix](Severity-Frequency-matrix/) | 1 | [`Severity-Frequency-matrix/`](Severity-Frequency-matrix/) |
| [TAM / SAM / SOM sizing](TAM-SAM-SOM-sizing/) | 2 | [`TAM-SAM-SOM-sizing/`](TAM-SAM-SOM-sizing/) |
| [TOD / PF / MD tariff analysis](TOD-PF-MD-tariff-analysis/) | 1 | [`TOD-PF-MD-tariff-analysis/`](TOD-PF-MD-tariff-analysis/) |
| [Unit economics / ROI](Unit-economics-ROI/) | 1 | [`Unit-economics-ROI/`](Unit-economics-ROI/) |
| [k-anonymity](k-anonymity/) | 1 | [`k-anonymity/`](k-anonymity/) |

[← Lens dashboard](../README.md)