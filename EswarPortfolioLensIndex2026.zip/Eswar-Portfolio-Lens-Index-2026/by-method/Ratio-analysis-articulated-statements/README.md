# Methods & Frameworks: Ratio analysis & articulated statements

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **Finance — Ratio Analysis & Aurora Consumer Foods** | Internship Studio | Case studies (D/E, dilution) and 2-year articulated statements reproducing target ratios with an investment verdict. | Ravi D/E 1.50→1.92; Vijay 10% issue = ₹2.6 L / 9.09% dilution; Aurora: BUY/ACCUMULATE | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/09-Financial-Ratio-Analysis-Aurora-Foods) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/09-Financial-Ratio-Analysis-Aurora-Foods/index.html) |

[← By Methods & Frameworks](../README.md) · [← Lens dashboard](../../README.md)