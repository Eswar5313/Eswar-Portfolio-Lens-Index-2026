# Methods & Frameworks: APFD test prioritisation

1 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **OrderFlow — Regression Test Prioritisation (APFD)** | Internship Studio | APFD / greedy prioritisation, set-cover reduction and 20-minute budget selection built in Excel with a report. | APFD 75.83% → 89.17%; reduced suite T7,T1,T6,T8 = 16 min (−62.8%) | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/03-Regression-Test-Prioritisation-APFD) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/03-Regression-Test-Prioritisation-APFD/index.html) |

[← By Methods & Frameworks](../README.md) · [← Lens dashboard](../../README.md)