# By Programme / Organisation

Where the work was done. 6 values across 83 projects.

| Programme / Organisation | Projects | Folder |
|---|:-:|---|
| [Airtribe / self-directed](Airtribe-self-directed/) | 8 | [`Airtribe-self-directed/`](Airtribe-self-directed/) |
| [Codec Technologies India](Codec-Technologies-India/) | 30 | [`Codec-Technologies-India/`](Codec-Technologies-India/) |
| [Data Analytics program](Data-Analytics-program/) | 4 | [`Data-Analytics-program/`](Data-Analytics-program/) |
| [HEXA Solutions, Ghaziabad NCR](HEXA-Solutions-Ghaziabad-NCR/) | 14 | [`HEXA-Solutions-Ghaziabad-NCR/`](HEXA-Solutions-Ghaziabad-NCR/) |
| [Internship Studio](Internship-Studio/) | 16 | [`Internship-Studio/`](Internship-Studio/) |
| [Self-initiated](Self-initiated/) | 11 | [`Self-initiated/`](Self-initiated/) |

[← Lens dashboard](../README.md)