# Target Role Fit: Supply Chain / Operations Manager

3 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **FedEx Logistics EDA** | HEXA Solutions | Exploratory analysis of shipment data — delivery timelines, route/mode mix, delay drivers and cost patterns, framed from a supply-chain operator's lens. | Delay-driver breakdown by mode and lane | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/01-HEXA-Data-Analytics/01-FedEx-Logistics-EDA) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/01-HEXA-Data-Analytics/01-FedEx-Logistics-EDA/index.html) |
| **The 2,000 SKU Problem — Blog** | Personal Builds | Quick-commerce dark-store assortment: capacity framing, ABC×XYZ + basket-role segmentation, replenishment clock, availability measurement. | 4 essays + hub | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/06-Personal-Builds-and-Sites/08-The-2000-SKU-Problem-Blog) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/06-Personal-Builds-and-Sites/08-The-2000-SKU-Problem-Blog/index.html) |
| **Company Assessments & Assignments** | Personal Builds | RoaDo FreightOS CSM/Ops analyst assessment (PDF, PPT, Excel, Python), InvestMyFunds CA-partner growth assignment, Tata Motors role targeting, Gen AI Academy APAC tracks. | Full submission packages delivered | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/06-Personal-Builds-and-Sites/11-Assessments-and-Assignments) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/06-Personal-Builds-and-Sites/11-Assessments-and-Assignments/index.html) |

[← By Target Role Fit](../README.md) · [← Lens dashboard](../../README.md)