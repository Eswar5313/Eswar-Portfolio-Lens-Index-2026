# Target Role Fit: Civil / Structural Engineer

2 projects. Each link opens the project folder in the master repository.

| Project | Track | What it is | Headline result | Files |
|---|---|---|---|---|
| **RCC Structural Design (IS 456)** | Internship Studio | One-way slab 10×4 m (M25/Fe415), doubly-reinforced hall slab + beam (M20/Fe415), biaxial column 3 m. | Slab D170 10@120; beam 400×750 8-32 + 8-25; column 300×450 8-16, interaction 0.389 | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/06-RCC-Structural-Design-IS456) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/06-RCC-Structural-Design-IS456/index.html) |
| **AutoCAD — Civil / Electrical / Mechanical Drawings** | Internship Studio | Single-storey plan, amplitude-limiter schematic + wiring schedule, screw-jack 7-part sheet + assembly/BOM authored as DXF. | 1,230 entities, DXF audit 0 errors | [folder](https://github.com/YOUR-USERNAME/Eswar-Master-Project-Portfolio-2026/tree/main/03-Internship-Studio-Projects/08-AutoCAD-Civil-Electrical-Mechanical) · [page](https://YOUR-USERNAME.github.io/Eswar-Master-Project-Portfolio-2026/03-Internship-Studio-Projects/08-AutoCAD-Civil-Electrical-Mechanical/index.html) |

[← By Target Role Fit](../README.md) · [← Lens dashboard](../../README.md)