# By Target Role Fit

Which job roles this project is evidence for. 14 values across 83 projects.

| Target Role Fit | Projects | Folder |
|---|:-:|---|
| [Business / Strategy Analyst](Business-Strategy-Analyst/) | 14 | [`Business-Strategy-Analyst/`](Business-Strategy-Analyst/) |
| [Civil / Structural Engineer](Civil-Structural-Engineer/) | 2 | [`Civil-Structural-Engineer/`](Civil-Structural-Engineer/) |
| [Cloud / DevOps Engineer](Cloud-DevOps-Engineer/) | 4 | [`Cloud-DevOps-Engineer/`](Cloud-DevOps-Engineer/) |
| [Data Analyst / BI Analyst](Data-Analyst-BI-Analyst/) | 42 | [`Data-Analyst-BI-Analyst/`](Data-Analyst-BI-Analyst/) |
| [Data Scientist / ML Engineer](Data-Scientist-ML-Engineer/) | 14 | [`Data-Scientist-ML-Engineer/`](Data-Scientist-ML-Engineer/) |
| [Designer (UX / Graphic)](Designer-UX-Graphic/) | 9 | [`Designer-UX-Graphic/`](Designer-UX-Graphic/) |
| [EV / Embedded / Electrical Engineer](EV-Embedded-Electrical-Engineer/) | 12 | [`EV-Embedded-Electrical-Engineer/`](EV-Embedded-Electrical-Engineer/) |
| [HR / People Operations](HR-People-Operations/) | 4 | [`HR-People-Operations/`](HR-People-Operations/) |
| [Marketing / Growth Manager](Marketing-Growth-Manager/) | 10 | [`Marketing-Growth-Manager/`](Marketing-Growth-Manager/) |
| [Product Manager / APM](Product-Manager-APM/) | 13 | [`Product-Manager-APM/`](Product-Manager-APM/) |
| [QA / Test Engineer](QA-Test-Engineer/) | 4 | [`QA-Test-Engineer/`](QA-Test-Engineer/) |
| [Security Analyst (SOC / Blue Team)](Security-Analyst-SOC-Blue-Team/) | 20 | [`Security-Analyst-SOC-Blue-Team/`](Security-Analyst-SOC-Blue-Team/) |
| [Software / Web Developer](Software-Web-Developer/) | 20 | [`Software-Web-Developer/`](Software-Web-Developer/) |
| [Supply Chain / Operations Manager](Supply-Chain-Operations-Manager/) | 3 | [`Supply-Chain-Operations-Manager/`](Supply-Chain-Operations-Manager/) |

[← Lens dashboard](../README.md)