# By Source Track

Folder in the master repository. 6 values across 83 projects.

| Source Track | Projects | Folder |
|---|:-:|---|
| [Codec Technologies — EV (10) + Cyber Security (20)](Codec-Technologies-EV-10-Cyber-Security-20/) | 30 | [`Codec-Technologies-EV-10-Cyber-Security-20/`](Codec-Technologies-EV-10-Cyber-Security-20/) |
| [Data Analytics Module 1 — Excel Mastery](Data-Analytics-Module-1-Excel-Mastery/) | 4 | [`Data-Analytics-Module-1-Excel-Mastery/`](Data-Analytics-Module-1-Excel-Mastery/) |
| [HEXA Solutions — Data Analytics Portfolio](HEXA-Solutions-Data-Analytics-Portfolio/) | 14 | [`HEXA-Solutions-Data-Analytics-Portfolio/`](HEXA-Solutions-Data-Analytics-Portfolio/) |
| [Internship Studio — 16 Multi-Domain Projects](Internship-Studio-16-Multi-Domain-Projects/) | 16 | [`Internship-Studio-16-Multi-Domain-Projects/`](Internship-Studio-16-Multi-Domain-Projects/) |
| [Personal Builds — Tools, Portfolio Sites & Blogs](Personal-Builds-Tools-Portfolio-Sites-Blogs/) | 11 | [`Personal-Builds-Tools-Portfolio-Sites-Blogs/`](Personal-Builds-Tools-Portfolio-Sites-Blogs/) |
| [Product Management — Case Studies](Product-Management-Case-Studies/) | 8 | [`Product-Management-Case-Studies/`](Product-Management-Case-Studies/) |

[← Lens dashboard](../README.md)